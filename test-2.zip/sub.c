#include <stdio.h>



int main() {
    
    char c;
    int count;
    printf("enter a letters for subsitution:\n");
    
    char alpha[26] = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
    for(count = 0; count < 26; count++){    //initialise array  
        
        
        scanf("%c", &c);        
        
        if(c > 96 && c < 123){
            c = c - 32;
        }
        printf("%c is substituted for %c\n", c, alpha[count]);
        c = alpha[count];
    
    }
    
    

  return 0;
    
}